
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CartService } from '../../services/cart.service';

@Component({
  standalone: true,
  imports: [CommonModule],
  templateUrl: './cart.html'
})
export class CartComponent {
  items: any[] = [];
  constructor(private cs: CartService) {
    this.load();
  }
  load() {
    this.cs.getCart().subscribe(d => this.items = d);
  }
  remove(id:number) {
    this.cs.removeFromCart(id).subscribe(()=>this.load());
  }
}
