
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../services/auth.service';

@Component({
  standalone: true,
  imports: [FormsModule],
  templateUrl: './register.html'
})
export class RegisterComponent {
  email=''; password='';
  constructor(private auth:AuthService){}
  register(){
    this.auth.register({email:this.email,password:this.password})
    .subscribe(()=>alert('Registered'));
  }
}
