
import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ProductService } from '../../services/product.service';
import { CartService } from '../../services/cart.service';

@Component({
  standalone: true,
  imports: [CommonModule],
  templateUrl: './product-details.html'
})
export class ProductDetailsComponent {
  product: any;
  constructor(route: ActivatedRoute, ps: ProductService, private cs: CartService) {
    const id = Number(route.snapshot.paramMap.get('id'));
    ps.getProduct(id).subscribe(d => this.product = d);
  }
  add() {
    this.cs.addToCart(this.product).subscribe(()=>alert('Added'));
  }
}
