
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({ providedIn: 'root' })
export class CartService {
  api = 'http://localhost:3000/cart';
  constructor(private http: HttpClient) {}
  getCart() { return this.http.get<any[]>(this.api); }
  addToCart(p: any) { return this.http.post(this.api, p); }
  removeFromCart(id: number) { return this.http.delete(`${this.api}/${id}`); }
}
